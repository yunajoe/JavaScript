/*
  함수선언 syntax 
  function 함수이름() {
    명령; 
    명령;  
  };

   함수호출 
   함수이름();

*/


 function printChorus(){
  console.log("무궁화 삼천리 화려 강산");
  console.log("대한 사람 대한으로 길이 보전하세"); 
 };

console.log('1절');
console.log('동해 물과 백두산이 마르고 닳도록');
console.log('하느님이 보우하사 우리나라 만세');
printChorus();


console.log('2절');
console.log('남산 위에 저 소나무 철갑을 두른 듯');
console.log('바람서리 불변함은 우리 기상일세');
printChorus();

console.log('3절');
console.log('가을 하늘 공활한데 높고 구름 없이');
console.log('밝은 달은 우리 가슴 일편단심일세');
printChorus();

console.log('4절');
console.log('이 기상과 이 맘으로 충성을 다하여');
console.log('괴로우나 즐거우나 나라 사랑하세');
printChorus();