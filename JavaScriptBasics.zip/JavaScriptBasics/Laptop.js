/*
## parameter
function welcome(name) {
  console.log("안녕하세요" + name + "님!");
  console.log("오늘도 좋은 하루 보내세요"); 
};

welcome("연아");
welcome("또또");

*/

function teraToGiga(TB) { 
  console.log(TB+"TB는");
  console.log(1024*TB+"GB 입니다.");

};

function teraToMega(TB){
  console.log(TB+"TB는");
  console.log(1024*1024*TB+"MB 입니다."); 
};

// TB -> GB 테스트
teraToGiga(2);
// TB -> MB 테스트
teraToMega(2);
