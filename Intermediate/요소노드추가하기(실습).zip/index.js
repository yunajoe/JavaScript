const toDoList = document.querySelector('#to-do-list');

function addNewTodo(text){
    // li태그 만들기
    const node = document.createElement('li');
    // li태그 안에 text값을 할당
    node.textContent = text;
    // li태그를 toDoList의 마지막 요소로 추가 
    toDoList.append(node);

} 

addNewTodo('자바스크립트 공부하기');
addNewTodo('고양이 화장실 청소하기');
addNewTodo('고양이 장난감 쇼핑하기');